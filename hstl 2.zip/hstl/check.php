<?php
  $login = ($_POST['login']);
  echo $login;
  $name = $_POST['name']
  $pass = ($_POST['pass'])
?>
