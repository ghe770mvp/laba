<?php
  $login = ($_POST['login']);
  $name = ($_POST['name']);
  $pass = ($_POST['pass']);

  $mysql = new mysql('localhost', 'root', 'root' 'users');
  $mysql->query("INSERT INTO `users` (`login`,`pass`,`name`)
  VALUES('$login','$pass','$name)");
  $mysql->close();
  header('Location: /');

?>
