<?
session_start();
//Данные
$host = "localhost"; //Хост, где проходит подключение. Без порта.
$user = "roor"; //Пользователь MySQL
$password = ""; //Пароль MySQL
$db_name = "test"; //Название базы

$connect = mysql_connect($host, $user, $password, $db_name) or die(mysql_error()); //Соединяемся, если не успешно, выводим ошибку.
mysql_select_db($db_name, $connect) or die(mysql_error()); //Выбираем базу, если не успешно, выводим ошибку.
?>