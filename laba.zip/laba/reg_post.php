 <?php
require ("../system/db.php");
if($_POST['login'] == "" OR $_POST['pass'] == ""){ 
header("Location: register.html"); //В случае, если пользователь не ввел логин или пароль, возвращаем его обратно.
}else { //Если все же ввел, то..
$login = $_POST['login']; //Определение для поля логина.
$pass = $_POST['pass']; //Определения для пароля.
$q =mysql_query("INSERT INTO `users`(`login`, `pass`) VALUES ('$login','$pass')"); //Вносим в базу введенную пользователем информацию.
header("Location: ../login.html"); //Перебрасываем пользователя на форму входа.
}
?>