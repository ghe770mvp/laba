 <?php
require ("../system/db.php"); //Подсоединяем файл с аргументами базы
session_start(); //Запускаем сессию.
if($_POST['login'] == "" OR $_POST['pass'] == ""){ 
header("Location: index.php"); //Возвращаем пользователя на форму входа, в случае если он не ввел данные входа.
}else { //Если все-же ввел, то..
 
$pass = $_POST['pass']; //Определение для пароля.
$login = $_POST['login']; //Определение для входа.
$pro = mysql_query("SELECT * FROM users WHERE login='$login' AND pass='$pass'"); //Запрашиваем список пользователей с полученными данными.
$res = mysql_fetch_array($pro); //Сокращаем.
if(mysql_num_rows($pro) == '0'){
header("Location: login.html"); //Если пользователей не найдено, то скидываем посетителя обратно на форму входа.
}else{ //Если все-же найдены пользователи с таким же логином и паролем, то..
$_SESSION['username'] = $res['login']; //Ставим инфу сессии.
$_SESSION['pass'] = $res['pass']; //Ставим инфу сессии.
header("Location: home.html"); //Перекидываем пользователя на индексную страницу сайта.
}
}
?>